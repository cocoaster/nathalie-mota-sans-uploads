# WordPress MySQL database migration
#
# Generated: Saturday 12. October 2024 10:36 UTC
# Hostname: localhost:10005
# Database: `local`
# URL: //nathalie-mota.local
# Path: C:\\Users\\ug\\Local Sites\\nathalie-mota\\app\\public
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_ewwwio_images, wp_ewwwio_queue, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wpforms_logs, wp_wpforms_payment_meta, wp_wpforms_payments, wp_wpforms_tasks_meta, wp_wpmailsmtp_debug_events, wp_wpmailsmtp_tasks_meta
# Table Prefix: wp_
# Post Types: revision, attachment, nav_menu_item, page, photo, post, wp_navigation
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(54, 'wp_mail_smtp_summary_report_email', 'complete', '2024-08-20 13:18:56', '2024-08-20 15:18:56', 10, '[null]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1724159936;s:18:"\0*\0first_timestamp";i:1722859200;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1724159936;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1724159936;s:15:"first_timestamp";i:1722859200;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1724159936;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2024-09-23 06:40:53', '2024-09-23 08:40:53', 0, NULL),
(56, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-08-15 13:27:57', '2024-08-15 15:27:57', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1723728477;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1723728477;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1723728477;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1723728477;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-09-23 06:40:53', '2024-09-23 08:40:53', 0, NULL),
(57, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-09-24 06:40:53', '2024-09-24 08:40:53', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1727160053;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1727160053;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1727160053;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1727160053;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-06 10:44:13', '2024-10-06 12:44:13', 0, NULL),
(58, 'wp_mail_smtp_summary_report_email', 'complete', '2024-09-30 06:40:53', '2024-09-30 08:40:53', 10, '[null]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1727678453;s:18:"\0*\0first_timestamp";i:1722859200;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1727678453;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1727678453;s:15:"first_timestamp";i:1722859200;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1727678453;s:19:"interval_in_seconds";i:604800;}', 2, 1, '2024-10-06 10:44:14', '2024-10-06 12:44:14', 0, NULL),
(59, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-10-07 10:44:13', '2024-10-07 12:44:13', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728297853;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728297853;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728297853;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728297853;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-07 16:12:33', '2024-10-07 18:12:33', 0, NULL),
(60, 'wp_mail_smtp_summary_report_email', 'pending', '2024-10-13 10:44:14', '2024-10-13 12:44:14', 10, '[null]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728816254;s:18:"\0*\0first_timestamp";i:1722859200;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728816254;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1728816254;s:15:"first_timestamp";i:1722859200;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1728816254;s:19:"interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(61, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-10-08 16:12:34', '2024-10-08 18:12:34', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728403954;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728403954;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728403954;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728403954;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-08 16:27:51', '2024-10-08 18:27:51', 0, NULL),
(62, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-10-09 16:27:51', '2024-10-09 18:27:51', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728491271;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728491271;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728491271;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728491271;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-09 19:38:59', '2024-10-09 21:38:59', 0, NULL),
(63, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-10-10 19:39:00', '2024-10-10 21:39:00', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728589140;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728589140;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728589140;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728589140;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-10 21:00:14', '2024-10-10 23:00:14', 0, NULL),
(64, 'wp_mail_smtp_admin_notifications_update', 'complete', '2024-10-11 21:00:14', '2024-10-11 23:00:14', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728680414;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728680414;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728680414;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728680414;s:19:"interval_in_seconds";i:86400;}', 2, 1, '2024-10-11 21:16:08', '2024-10-11 23:16:08', 0, NULL),
(65, 'wpforms_process_forms_locator_scan', 'complete', '2024-10-11 16:05:24', '2024-10-11 18:05:24', 10, '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728662724;s:18:"\0*\0first_timestamp";i:1728662724;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728662724;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728662724;s:15:"first_timestamp";i:1728662724;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728662724;s:19:"interval_in_seconds";i:86400;}', 3, 1, '2024-10-11 16:05:26', '2024-10-11 18:05:26', 0, NULL),
(66, 'wpforms_process_purge_spam', 'complete', '2024-10-11 16:05:24', '2024-10-11 18:05:24', 10, '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728662724;s:18:"\0*\0first_timestamp";i:1728662724;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728662724;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728662724;s:15:"first_timestamp";i:1728662724;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728662724;s:19:"interval_in_seconds";i:86400;}', 3, 1, '2024-10-11 16:05:26', '2024-10-11 18:05:26', 0, NULL),
(67, 'wpforms_email_summaries_fetch_info_blocks', 'complete', '2024-10-09 03:49:56', '2024-10-09 05:49:56', 10, '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728445796;s:18:"\0*\0first_timestamp";i:1728445796;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728445796;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1728445796;s:15:"first_timestamp";i:1728445796;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1728445796;s:19:"interval_in_seconds";i:604800;}', 3, 1, '2024-10-11 16:05:26', '2024-10-11 18:05:26', 0, NULL),
(68, 'wpforms_email_summaries_fetch_info_blocks', 'pending', '2024-10-18 16:05:26', '2024-10-18 18:05:26', 10, '{"tasks_meta_id":null}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1729267526;s:18:"\0*\0first_timestamp";i:1728445796;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1729267526;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;s:19:"scheduled_timestamp";i:1729267526;s:15:"first_timestamp";i:1728445796;s:10:"recurrence";i:604800;s:15:"start_timestamp";i:1729267526;s:19:"interval_in_seconds";i:604800;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(69, 'wpforms_process_forms_locator_scan', 'pending', '2024-10-12 16:05:26', '2024-10-12 18:05:26', 10, '{"tasks_meta_id":1}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728749126;s:18:"\0*\0first_timestamp";i:1728662724;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728749126;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728749126;s:15:"first_timestamp";i:1728662724;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728749126;s:19:"interval_in_seconds";i:86400;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(70, 'wpforms_process_purge_spam', 'pending', '2024-10-12 16:05:27', '2024-10-12 18:05:27', 10, '{"tasks_meta_id":2}', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728749127;s:18:"\0*\0first_timestamp";i:1728662724;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728749127;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728749127;s:15:"first_timestamp";i:1728662724;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728749127;s:19:"interval_in_seconds";i:86400;}', 3, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(71, 'wpforms_admin_notifications_update', 'complete', '2024-10-11 16:05:56', '2024-10-11 16:05:56', 10, '{"tasks_meta_id":3}', 'O:28:"ActionScheduler_NullSchedule":0:{}', 3, 1, '2024-10-11 16:05:59', '2024-10-11 18:05:59', 0, NULL),
(72, 'wp_mail_smtp_admin_notifications_update', 'pending', '2024-10-12 21:16:08', '2024-10-12 23:16:08', 10, '[1]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1728767768;s:18:"\0*\0first_timestamp";i:1722330719;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1728767768;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1728767768;s:15:"first_timestamp";i:1722330719;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1728767768;s:19:"interval_in_seconds";i:86400;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(73, 'action_scheduler/migration_hook', 'complete', '2024-10-12 09:42:12', '2024-10-12 11:42:12', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1728726132;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1728726132;s:19:"scheduled_timestamp";i:1728726132;s:9:"timestamp";i:1728726132;}', 1, 1, '2024-10-12 09:42:20', '2024-10-12 11:42:20', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=1634 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wp_mail_smtp'),
(3, 'wpforms') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(44, 54, 'action created', '2024-08-13 13:18:56', '2024-08-13 15:18:56'),
(50, 56, 'action created', '2024-08-14 13:27:57', '2024-08-14 15:27:57'),
(51, 56, 'action started via WP Cron', '2024-09-23 06:40:52', '2024-09-23 08:40:52'),
(52, 56, 'action complete via WP Cron', '2024-09-23 06:40:53', '2024-09-23 08:40:53'),
(53, 57, 'action created', '2024-09-23 06:40:53', '2024-09-23 08:40:53'),
(54, 54, 'action started via WP Cron', '2024-09-23 06:40:53', '2024-09-23 08:40:53'),
(55, 54, 'action complete via WP Cron', '2024-09-23 06:40:53', '2024-09-23 08:40:53'),
(56, 58, 'action created', '2024-09-23 06:40:53', '2024-09-23 08:40:53'),
(57, 57, 'action started via Async Request', '2024-10-06 10:44:13', '2024-10-06 12:44:13'),
(58, 57, 'action complete via Async Request', '2024-10-06 10:44:13', '2024-10-06 12:44:13'),
(59, 59, 'action created', '2024-10-06 10:44:13', '2024-10-06 12:44:13'),
(60, 58, 'action started via Async Request', '2024-10-06 10:44:13', '2024-10-06 12:44:13'),
(61, 58, 'action complete via Async Request', '2024-10-06 10:44:14', '2024-10-06 12:44:14'),
(62, 60, 'action created', '2024-10-06 10:44:14', '2024-10-06 12:44:14'),
(63, 59, 'action started via WP Cron', '2024-10-07 16:12:30', '2024-10-07 18:12:30'),
(64, 59, 'action complete via WP Cron', '2024-10-07 16:12:33', '2024-10-07 18:12:33'),
(65, 61, 'action created', '2024-10-07 16:12:34', '2024-10-07 18:12:34'),
(66, 61, 'action started via WP Cron', '2024-10-08 16:27:50', '2024-10-08 18:27:50'),
(67, 61, 'action complete via WP Cron', '2024-10-08 16:27:51', '2024-10-08 18:27:51'),
(68, 62, 'action created', '2024-10-08 16:27:51', '2024-10-08 18:27:51'),
(69, 62, 'action started via WP Cron', '2024-10-09 19:38:58', '2024-10-09 21:38:58'),
(70, 62, 'action complete via WP Cron', '2024-10-09 19:38:59', '2024-10-09 21:38:59'),
(71, 63, 'action created', '2024-10-09 19:39:00', '2024-10-09 21:39:00'),
(72, 63, 'action started via WP Cron', '2024-10-10 21:00:14', '2024-10-10 23:00:14'),
(73, 63, 'action complete via WP Cron', '2024-10-10 21:00:14', '2024-10-10 23:00:14'),
(74, 64, 'action created', '2024-10-10 21:00:14', '2024-10-10 23:00:14'),
(75, 65, 'action created', '2024-10-11 16:05:24', '2024-10-11 18:05:24'),
(76, 66, 'action created', '2024-10-11 16:05:24', '2024-10-11 18:05:24'),
(77, 67, 'action created', '2024-10-11 16:05:24', '2024-10-11 18:05:24'),
(78, 67, 'action started via WP Cron', '2024-10-11 16:05:25', '2024-10-11 18:05:25'),
(79, 67, 'action complete via WP Cron', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(80, 68, 'action created', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(81, 65, 'action started via WP Cron', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(82, 65, 'action complete via WP Cron', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(83, 69, 'action created', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(84, 66, 'action started via WP Cron', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(85, 66, 'action complete via WP Cron', '2024-10-11 16:05:26', '2024-10-11 18:05:26'),
(86, 70, 'action created', '2024-10-11 16:05:27', '2024-10-11 18:05:27'),
(87, 71, 'action created', '2024-10-11 16:05:57', '2024-10-11 18:05:57'),
(88, 71, 'action started via Async Request', '2024-10-11 16:05:58', '2024-10-11 18:05:58'),
(89, 71, 'action complete via Async Request', '2024-10-11 16:05:59', '2024-10-11 18:05:59'),
(90, 64, 'action started via WP Cron', '2024-10-11 21:16:07', '2024-10-11 23:16:07'),
(91, 64, 'action complete via WP Cron', '2024-10-11 21:16:08', '2024-10-11 23:16:08'),
(92, 72, 'action created', '2024-10-11 21:16:08', '2024-10-11 23:16:08'),
(93, 73, 'action created', '2024-10-12 09:41:12', '2024-10-12 11:41:12'),
(94, 73, 'action started via WP Cron', '2024-10-12 09:42:20', '2024-10-12 11:42:20'),
(95, 73, 'action complete via WP Cron', '2024-10-12 09:42:20', '2024-10-12 11:42:20') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-07-26 17:07:05', '2024-07-26 17:07:05', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_images`
#

DROP TABLE IF EXISTS `wp_ewwwio_images`;


#
# Table structure of table `wp_ewwwio_images`
#

CREATE TABLE `wp_ewwwio_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `retrieve` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int(10) unsigned DEFAULT NULL,
  `resized_width` smallint(5) unsigned DEFAULT NULL,
  `resized_height` smallint(5) unsigned DEFAULT NULL,
  `resize_error` tinyint(3) unsigned DEFAULT NULL,
  `webp_size` int(10) unsigned DEFAULT NULL,
  `webp_error` tinyint(3) unsigned DEFAULT NULL,
  `pending` tinyint(4) NOT NULL DEFAULT '0',
  `updates` int(10) unsigned DEFAULT NULL,
  `updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob,
  PRIMARY KEY (`id`),
  KEY `path` (`path`(191)),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_ewwwio_images`
#
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `image_size`, `orig_size`, `backup`, `retrieve`, `level`, `resized_width`, `resized_height`, `resize_error`, `webp_size`, `webp_error`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 37, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-scaled.jpeg', '', 638948, 657724, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:22', NULL),
(2, 37, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-200x300.jpeg', '', 18229, 19677, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:22', NULL),
(3, 37, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-684x1024.jpeg', '', 145631, 152305, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:22', NULL),
(4, 37, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-150x150.jpeg', '', 8026, 8560, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:23', NULL),
(5, 37, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-768x1150.jpeg', '', 175490, 183100, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:23', NULL),
(6, 37, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-1025x1536.jpeg', '', 282412, 293220, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:24', NULL),
(7, 37, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1-1367x2048.jpeg', '', 446586, 461291, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:24', NULL),
(8, 36, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-scaled.jpeg', '', 450275, 470897, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:25', NULL),
(9, 36, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-200x300.jpeg', '', 10823, 11483, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:26', NULL),
(10, 36, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-683x1024.jpeg', '', 91908, 96567, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:26', NULL),
(11, 36, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-150x150.jpeg', '', 5178, 5717, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:26', NULL),
(12, 36, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-768x1152.jpeg', '', 111805, 117440, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:27', NULL),
(13, 36, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-1024x1536.jpeg', '', 184903, 194071, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:27', NULL),
(14, 36, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1-1365x2048.jpeg', '', 304802, 319293, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:28', NULL),
(15, 35, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-scaled.jpeg', '', 268514, 271340, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:29', NULL),
(16, 35, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-200x300.jpeg', '', 10048, 10584, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:29', NULL),
(17, 35, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-683x1024.jpeg', '', 65536, 67271, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:30', NULL),
(18, 35, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-150x150.jpeg', '', 5359, 5904, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:30', NULL),
(19, 35, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-768x1152.jpeg', '', 77831, 79605, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:31', NULL),
(20, 35, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-1024x1536.jpeg', '', 120510, 123124, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:31', NULL),
(21, 35, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1-1365x2048.jpeg', '', 186989, 189807, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:31', NULL),
(22, 34, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-scaled.jpeg', '', 490634, 499851, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:32', NULL),
(23, 34, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-300x200.jpeg', '', 17884, 19136, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:32', NULL),
(24, 34, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-1024x683.jpeg', '', 122549, 127114, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:33', NULL),
(25, 34, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-150x150.jpeg', '', 8897, 9437, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:33', NULL),
(26, 34, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-768x512.jpeg', '', 78366, 81929, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:33', NULL),
(27, 34, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-1536x1024.jpeg', '', 224118, 230427, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:34', NULL),
(28, 34, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1-2048x1365.jpeg', '', 347717, 355609, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:34', NULL),
(29, 33, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-scaled.jpeg', '', 347135, 353187, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:35', NULL),
(30, 33, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-300x200.jpeg', '', 14579, 15413, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:35', NULL),
(31, 33, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-1024x684.jpeg', '', 87705, 89429, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:36', NULL),
(32, 33, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-150x150.jpeg', '', 7169, 7708, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:36', NULL),
(33, 33, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-768x513.jpeg', '', 57990, 59663, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:37', NULL),
(34, 33, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-1536x1025.jpeg', '', 157668, 159946, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:37', NULL),
(35, 33, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-11-1-2048x1367.jpeg', '', 242665, 246299, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:37', NULL),
(36, 32, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-scaled.jpeg', '', 1285340, 1361452, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:38', NULL),
(37, 32, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-300x225.jpeg', '', 24481, 26249, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:39', NULL),
(38, 32, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-1024x768.jpeg', '', 251404, 268479, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:39', NULL),
(39, 32, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-150x150.jpeg', '', 9004, 9542, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:40', NULL),
(40, 32, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-768x576.jpeg', '', 146050, 156459, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:40', NULL),
(41, 32, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-1536x1152.jpeg', '', 529642, 564284, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:40', NULL),
(42, 32, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1-2048x1536.jpeg', '', 880316, 935859, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:41', NULL),
(43, 31, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-scaled.jpeg', '', 597780, 621814, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:42', NULL),
(44, 31, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-300x200.jpeg', '', 13921, 14785, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:42', NULL),
(45, 31, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-1024x683.jpeg', '', 111349, 114661, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:43', NULL),
(46, 31, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-150x150.jpeg', '', 6893, 7430, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:43', NULL),
(47, 31, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-768x512.jpeg', '', 67418, 69647, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:44', NULL),
(48, 31, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-1536x1024.jpeg', '', 226691, 234321, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:44', NULL),
(49, 31, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1-2048x1365.jpeg', '', 389043, 403356, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:45', NULL),
(50, 30, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-scaled.jpeg', '', 427252, 433893, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:45', NULL),
(51, 30, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-200x300.jpeg', '', 16431, 17475, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:46', NULL),
(52, 30, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-684x1024.jpeg', '', 106129, 108656, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:47', NULL),
(53, 30, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-150x150.jpeg', '', 8382, 8923, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:47', NULL),
(54, 30, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-768x1150.jpeg', '', 126112, 128874, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:47', NULL),
(55, 30, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-1025x1536.jpeg', '', 195415, 198503, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:48', NULL),
(56, 30, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1-1367x2048.jpeg', '', 301647, 305925, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:48', NULL),
(57, 29, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-scaled.jpeg', '', 380424, 382412, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:49', NULL),
(58, 29, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-300x200.jpeg', '', 13363, 14082, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:49', NULL),
(59, 29, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-1024x683.jpeg', '', 90730, 92020, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:50', NULL),
(60, 29, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-150x150.jpeg', '', 6040, 6585, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:50', NULL),
(61, 29, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-768x512.jpeg', '', 58147, 59369, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:51', NULL),
(62, 29, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-1536x1024.jpeg', '', 169001, 170145, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:51', NULL),
(63, 29, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1-2048x1365.jpeg', '', 266019, 267624, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:52', NULL),
(64, 28, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-scaled.jpeg', '', 689036, 713303, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:52', NULL),
(65, 28, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-300x240.jpeg', '', 14419, 15182, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:53', NULL),
(66, 28, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-1024x819.jpeg', '', 112905, 116969, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:53', NULL),
(67, 28, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-150x150.jpeg', '', 5847, 6387, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:53', NULL),
(68, 28, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-768x614.jpeg', '', 67678, 69956, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:54', NULL),
(69, 28, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-1536x1229.jpeg', '', 241982, 250914, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:54', NULL),
(70, 28, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1-2048x1638.jpeg', '', 433586, 450294, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:55', NULL),
(71, 27, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-scaled.jpeg', '', 758221, 795730, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:56', NULL),
(72, 27, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-200x300.jpeg', '', 18435, 19806, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:56', NULL),
(73, 27, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-683x1024.jpeg', '', 147713, 155123, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:57', NULL),
(74, 27, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-150x150.jpeg', '', 8068, 8609, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:57', NULL),
(75, 27, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-768x1152.jpeg', '', 179851, 188942, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:58', NULL),
(76, 27, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-1024x1536.jpeg', '', 294798, 309370, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:58', NULL),
(77, 27, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1-1365x2048.jpeg', '', 496246, 520741, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:11:59', NULL),
(78, 26, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-scaled.jpeg', '', 645935, 668092, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:00', NULL),
(79, 26, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-200x300.jpeg', '', 17554, 18692, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:00', NULL),
(80, 26, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-683x1024.jpeg', '', 146035, 152055, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:01', NULL),
(81, 26, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-150x150.jpeg', '', 7596, 8137, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:01', NULL),
(82, 26, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-768x1152.jpeg', '', 176135, 183084, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:01', NULL),
(83, 26, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-1024x1536.jpeg', '', 281102, 291050, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:02', NULL),
(84, 26, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1-1365x2048.jpeg', '', 448668, 464140, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:02', NULL),
(85, 25, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-scaled.jpeg', '', 237385, 237753, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:03', NULL),
(86, 25, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-200x300.jpeg', '', 9577, 10117, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:03', NULL),
(87, 25, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-683x1024.jpeg', '', 57784, 58656, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:04', NULL),
(88, 25, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-150x150.jpeg', '', 4503, 5043, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:06', NULL),
(89, 25, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-768x1152.jpeg', '', 67806, 68681, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:06', NULL),
(90, 25, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-1024x1536.jpeg', '', 104188, 104998, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:07', NULL),
(91, 25, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1-1365x2048.jpeg', '', 162701, 163213, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:08', NULL),
(92, 24, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-scaled.jpeg', '', 907847, 962040, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:08', NULL),
(93, 24, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-300x181.jpeg', '', 19255, 20800, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:09', NULL),
(94, 24, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-1024x617.jpeg', '', 183552, 195356, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:09', NULL),
(95, 24, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-150x150.jpeg', '', 9479, 10415, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:10', NULL),
(96, 24, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-768x463.jpeg', '', 109460, 116944, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:10', NULL),
(97, 24, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-1536x926.jpeg', '', 373840, 397242, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:11', NULL),
(98, 24, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1-2048x1235.jpeg', '', 618530, 656045, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:12', NULL),
(99, 23, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-scaled.jpeg', '', 584481, 597357, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:12', NULL),
(100, 23, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-300x200.jpeg', '', 18017, 19127, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:13', NULL) ;
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `image_size`, `orig_size`, `backup`, `retrieve`, `level`, `resized_width`, `resized_height`, `resize_error`, `webp_size`, `webp_error`, `pending`, `updates`, `updated`, `trace`) VALUES
(101, 23, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-1024x683.jpeg', '', 132006, 135592, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:13', NULL),
(102, 23, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-150x150.jpeg', '', 7965, 8513, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:14', NULL),
(103, 23, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-768x512.jpeg', '', 83298, 85929, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:14', NULL),
(104, 23, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-1536x1024.jpeg', '', 252522, 258314, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:15', NULL),
(105, 23, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1-2048x1365.jpeg', '', 401056, 409230, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:15', NULL),
(106, 22, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-scaled.jpeg', '', 354978, 358300, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:16', NULL),
(107, 22, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-300x200.jpeg', '', 14029, 14887, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:16', NULL),
(108, 22, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-1024x683.jpeg', '', 84676, 86136, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:17', NULL),
(109, 22, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-150x150.jpeg', '', 6928, 7471, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:17', NULL),
(110, 22, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-768x512.jpeg', '', 55540, 57060, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:17', NULL),
(111, 22, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-1536x1024.jpeg', '', 154570, 156226, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:18', NULL),
(112, 22, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1-2048x1365.jpeg', '', 242038, 244086, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:18', NULL),
(113, NULL, NULL, NULL, 'ABSPATHwp-content/themes/nathalie-mota\\Screenshot.png', '', 617914, 617914, '', NULL, 10, NULL, NULL, NULL, NULL, NULL, 0, 1, '2024-07-30 11:12:21', NULL) ;

#
# End of data contents of table `wp_ewwwio_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_queue`
#

DROP TABLE IF EXISTS `wp_ewwwio_queue`;


#
# Table structure of table `wp_ewwwio_queue`
#

CREATE TABLE `wp_ewwwio_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `gallery` varchar(20) DEFAULT NULL,
  `scanned` tinyint(4) NOT NULL DEFAULT '0',
  `new` tinyint(4) NOT NULL DEFAULT '0',
  `convert_once` tinyint(4) NOT NULL DEFAULT '0',
  `force_reopt` tinyint(4) NOT NULL DEFAULT '0',
  `force_smart` tinyint(4) NOT NULL DEFAULT '0',
  `webp_only` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_ewwwio_queue`
#

#
# End of data contents of table `wp_ewwwio_queue`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=3129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'cron', 'a:19:{i:1728729417;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1728729617;a:1:{s:29:"rsssl_every_five_minutes_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:18:"rsssl_five_minutes";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1728731227;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1728737417;a:1:{s:28:"rsssl_every_three_hours_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:23:"rsssl_every_three_hours";s:4:"args";a:0:{}s:8:"interval";i:10800;}}}i:1728752015;a:1:{s:15:"ao_cachechecker";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728752827;a:2:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728753637;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728753639;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728756423;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728758223;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728760023;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1728766824;a:1:{s:21:"ai1wm_storage_cleanup";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728791417;a:1:{s:20:"rsssl_every_day_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"rsssl_daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1728856800;a:1:{s:33:"wpforms_weekly_entries_count_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1728907200;a:1:{s:28:"wpforms_email_summaries_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1729272074;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1729309817;a:1:{s:21:"rsssl_every_week_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:12:"rsssl_weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1731297017;a:1:{s:22:"rsssl_every_month_hook";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:13:"rsssl_monthly";s:4:"args";a:0:{}s:8:"interval";i:2592000;}}}s:7:"version";i:2;}', 'auto'),
(2, 'siteurl', 'http://nathalie-mota.local/', 'on'),
(3, 'home', 'http://nathalie-mota.local/', 'on'),
(4, 'blogname', 'nathalie mota', 'on'),
(5, 'blogdescription', '', 'on'),
(6, 'users_can_register', '0', 'on'),
(7, 'admin_email', 'dev-email@wpengine.local', 'on'),
(8, 'start_of_week', '1', 'on'),
(9, 'use_balanceTags', '0', 'on'),
(10, 'use_smilies', '1', 'on'),
(11, 'require_name_email', '1', 'on'),
(12, 'comments_notify', '1', 'on'),
(13, 'posts_per_rss', '10', 'on'),
(14, 'rss_use_excerpt', '0', 'on'),
(15, 'mailserver_url', 'mail.example.com', 'on'),
(16, 'mailserver_login', 'login@example.com', 'on'),
(17, 'mailserver_pass', 'password', 'on'),
(18, 'mailserver_port', '110', 'on'),
(19, 'default_category', '1', 'on'),
(20, 'default_comment_status', 'open', 'on'),
(21, 'default_ping_status', 'open', 'on'),
(22, 'default_pingback_flag', '1', 'on'),
(23, 'posts_per_page', '10', 'on'),
(24, 'date_format', 'F j, Y', 'on'),
(25, 'time_format', 'g:i a', 'on'),
(26, 'links_updated_date_format', 'F j, Y g:i a', 'on'),
(27, 'comment_moderation', '0', 'on'),
(28, 'moderation_notify', '1', 'on'),
(29, 'permalink_structure', '/%postname%/', 'on'),
(30, 'rewrite_rules', 'a:116:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"photos/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"photos/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"photos/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"photos/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"photos/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"photos/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"photos/([^/]+)/embed/?$";s:38:"index.php?photo=$matches[1]&embed=true";s:27:"photos/([^/]+)/trackback/?$";s:32:"index.php?photo=$matches[1]&tb=1";s:35:"photos/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?photo=$matches[1]&paged=$matches[2]";s:42:"photos/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?photo=$matches[1]&cpage=$matches[2]";s:31:"photos/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?photo=$matches[1]&page=$matches[2]";s:23:"photos/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"photos/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"photos/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"photos/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"photos/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"photos/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:"formats/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?format=$matches[1]&feed=$matches[2]";s:43:"formats/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?format=$matches[1]&feed=$matches[2]";s:24:"formats/([^/]+)/embed/?$";s:39:"index.php?format=$matches[1]&embed=true";s:36:"formats/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?format=$matches[1]&paged=$matches[2]";s:18:"formats/([^/]+)/?$";s:28:"index.php?format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=5&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'on'),
(31, 'hack_file', '0', 'on'),
(32, 'blog_charset', 'UTF-8', 'on'),
(33, 'moderation_keys', '', 'off'),
(34, 'active_plugins', 'a:8:{i:0;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:1;s:27:"autoptimize/autoptimize.php";i:2;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:3;s:47:"really-simple-ssl/rlrsssl-really-simple-ssl.php";i:4;s:29:"wp-mail-smtp/wp_mail_smtp.php";i:5;s:31:"wp-migrate-db/wp-migrate-db.php";i:6;s:27:"wp-super-cache/wp-cache.php";i:7;s:24:"wpforms-lite/wpforms.php";}', 'on'),
(35, 'category_base', '', 'on'),
(36, 'ping_sites', 'http://rpc.pingomatic.com/', 'on'),
(37, 'comment_max_links', '2', 'on'),
(38, 'gmt_offset', '', 'on'),
(39, 'default_email_category', '1', 'on'),
(40, 'recently_edited', '', 'off'),
(41, 'template', 'nathalie-mota', 'on'),
(42, 'stylesheet', 'nathalie-mota', 'on'),
(43, 'comment_registration', '0', 'on'),
(44, 'html_type', 'text/html', 'on'),
(45, 'use_trackback', '0', 'on'),
(46, 'default_role', 'subscriber', 'on'),
(47, 'db_version', '57155', 'on'),
(48, 'uploads_use_yearmonth_folders', '1', 'on'),
(49, 'upload_path', '', 'on'),
(50, 'blog_public', '1', 'on'),
(51, 'default_link_category', '2', 'on'),
(52, 'show_on_front', 'page', 'on'),
(53, 'tag_base', '', 'on'),
(54, 'show_avatars', '1', 'on'),
(55, 'avatar_rating', 'G', 'on'),
(56, 'upload_url_path', '', 'on'),
(57, 'thumbnail_size_w', '150', 'on'),
(58, 'thumbnail_size_h', '150', 'on'),
(59, 'thumbnail_crop', '1', 'on'),
(60, 'medium_size_w', '300', 'on'),
(61, 'medium_size_h', '300', 'on'),
(62, 'avatar_default', 'mystery', 'on'),
(63, 'large_size_w', '1024', 'on'),
(64, 'large_size_h', '1024', 'on'),
(65, 'image_default_link_type', 'none', 'on'),
(66, 'image_default_size', '', 'on'),
(67, 'image_default_align', '', 'on'),
(68, 'close_comments_for_old_posts', '0', 'on'),
(69, 'close_comments_days_old', '14', 'on'),
(70, 'thread_comments', '1', 'on'),
(71, 'thread_comments_depth', '5', 'on'),
(72, 'page_comments', '0', 'on'),
(73, 'comments_per_page', '50', 'on'),
(74, 'default_comments_page', 'newest', 'on'),
(75, 'comment_order', 'asc', 'on'),
(76, 'sticky_posts', 'a:0:{}', 'on'),
(77, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'auto'),
(80, 'uninstall_plugins', 'a:2:{s:27:"autoptimize/autoptimize.php";s:29:"autoptimizeMain::on_uninstall";s:27:"wp-super-cache/wp-cache.php";s:22:"wpsupercache_uninstall";}', 'off'),
(81, 'timezone_string', 'Europe/Paris', 'on'),
(82, 'page_for_posts', '0', 'on'),
(83, 'page_on_front', '5', 'on'),
(84, 'default_post_format', '0', 'on'),
(85, 'link_manager_enabled', '0', 'on'),
(86, 'finished_splitting_shared_terms', '1', 'on'),
(87, 'site_icon', '0', 'on'),
(88, 'medium_large_size_w', '768', 'on'),
(89, 'medium_large_size_h', '0', 'on'),
(90, 'wp_page_for_privacy_policy', '3', 'on'),
(91, 'show_comments_cookies_opt_in', '1', 'on'),
(92, 'admin_email_lifespan', '1737565623', 'on'),
(93, 'disallowed_keys', '', 'off'),
(94, 'comment_previously_approved', '1', 'on'),
(95, 'auto_plugin_theme_update_emails', 'a:0:{}', 'off'),
(96, 'auto_update_core_dev', 'enabled', 'on'),
(97, 'auto_update_core_minor', 'enabled', 'on'),
(98, 'auto_update_core_major', 'enabled', 'on'),
(99, 'wp_force_deactivated_plugins', 'a:0:{}', 'on'),
(100, 'wp_attachment_pages_enabled', '0', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'initial_db_version', '57155', 'on'),
(102, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"manage_security";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'auto'),
(103, 'fresh_site', '0', 'auto'),
(104, 'user_count', '1', 'off'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'auto'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'auto'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(125, 'recovery_keys', 'a:1:{s:22:"BLbKhYvz4L6ZQKeVJeUMZH";a:2:{s:10:"hashed_key";s:34:"$P$BCm.869c6G0z6IjvRZqyM1S1kNLLfy.";s:10:"created_at";i:1728643079;}}', 'auto'),
(150, 'can_compress_scripts', '1', 'yes'),
(153, 'finished_updating_comment_type', '1', 'yes'),
(154, 'WPLANG', 'fr_FR', 'yes'),
(155, 'new_admin_email', 'dev-email@wpengine.local', 'yes'),
(159, 'recently_activated', 'a:0:{}', 'yes'),
(165, 'theme_mods_twentytwentyfour', 'a:4:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1722892345;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}s:19:"wp_classic_sidebars";a:0:{}s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'off'),
(166, 'current_theme', 'nathalie mota', 'yes'),
(167, 'theme_mods_nathalie-mota', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main-menu";i:2;s:11:"footer-menu";i:5;}s:18:"custom_css_post_id";i:-1;s:10:"hero_image";s:78:"http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-0-1-scaled.jpeg";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1722892282;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'on'),
(168, 'theme_switched', '', 'yes'),
(197, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'auto'),
(203, 'autoptimize_version', '3.1.12', 'auto'),
(204, 'autoptimize_ccss_version', 'AO_3.1.12', 'auto'),
(206, 'autoptimize_service_availablity', 'a:3:{s:12:"extra_imgopt";a:3:{s:6:"status";s:2:"up";s:5:"hosts";a:1:{i:1;s:28:"https://sp-ao.shortpixel.ai/";}s:16:"launch-threshold";s:4:"4096";}s:7:"critcss";a:2:{s:6:"status";s:2:"up";s:5:"hosts";a:1:{i:1;s:24:"https://criticalcss.com/";}}s:9:"rapidload";a:1:{s:6:"status";s:2:"up";}}', 'auto'),
(207, 'ewww_image_optimizer_relative_migration_status', 'done', 'auto'),
(209, 'ewww_image_optimizer_background_optimization', '1', 'off'),
(210, 'ewww_image_optimizer_noauto', '', 'auto'),
(211, 'ewww_image_optimizer_disable_editor', '', 'auto'),
(212, 'ewww_image_optimizer_debug', '', 'auto'),
(213, 'ewww_image_optimizer_metadata_remove', '1', 'auto'),
(214, 'ewww_image_optimizer_jpg_level', '10', 'auto'),
(215, 'ewww_image_optimizer_png_level', '10', 'auto'),
(216, 'ewww_image_optimizer_gif_level', '10', 'auto'),
(217, 'ewww_image_optimizer_pdf_level', '0', 'auto'),
(218, 'ewww_image_optimizer_svg_level', '0', 'auto'),
(219, 'ewww_image_optimizer_jpg_quality', '', 'auto'),
(220, 'ewww_image_optimizer_webp_quality', '', 'auto'),
(221, 'ewww_image_optimizer_backup_files', '', 'auto'),
(222, 'ewww_image_optimizer_resize_existing', '1', 'auto'),
(223, 'ewww_image_optimizer_exactdn', '', 'auto'),
(224, 'ewww_image_optimizer_exactdn_plan_id', '0', 'auto'),
(225, 'exactdn_all_the_things', '1', 'auto'),
(226, 'exactdn_lossy', '1', 'auto'),
(227, 'exactdn_exclude', '', 'auto'),
(228, 'exactdn_sub_folder', '', 'off'),
(229, 'exactdn_prevent_db_queries', '', 'auto'),
(230, 'exactdn_asset_domains', '', 'auto'),
(231, 'ewww_image_optimizer_lazy_load', '', 'auto'),
(232, 'ewww_image_optimizer_add_missing_dims', '', 'auto'),
(233, 'ewww_image_optimizer_use_siip', '', 'auto'),
(234, 'ewww_image_optimizer_use_lqip', '', 'auto'),
(235, 'ewww_image_optimizer_use_dcip', '', 'auto'),
(236, 'ewww_image_optimizer_ll_exclude', '', 'auto'),
(237, 'ewww_image_optimizer_ll_all_things', '', 'auto'),
(238, 'ewww_image_optimizer_disable_pngout', '1', 'auto'),
(239, 'ewww_image_optimizer_disable_svgcleaner', '1', 'auto'),
(240, 'ewww_image_optimizer_optipng_level', '2', 'auto'),
(241, 'ewww_image_optimizer_pngout_level', '2', 'auto'),
(242, 'ewww_image_optimizer_webp_for_cdn', '', 'auto'),
(243, 'ewww_image_optimizer_force_gif2webp', '1', 'auto'),
(244, 'ewww_image_optimizer_picture_webp', '', 'auto'),
(245, 'ewww_image_optimizer_webp_rewrite_exclude', '', 'auto'),
(248, 'ewww_image_optimizer_ll_autoscale', '1', 'off'),
(249, 'exactdn_never_been_active', '1', 'off'),
(250, 'ewww_image_optimizer_bulk_resume', '', 'auto'),
(251, 'ewww_image_optimizer_aux_resume', '', 'auto'),
(252, 'ewww_image_optimizer_flag_attachments', '', 'off'),
(253, 'ewww_image_optimizer_ngg_attachments', '', 'off'),
(255, 'ewww_image_optimizer_review_time', '1722935385', 'off'),
(256, 'ewww_image_optimizer_version', '790', 'auto'),
(257, 'action_scheduler_hybrid_store_demarkation', '38', 'auto'),
(258, 'schema-ActionScheduler_StoreSchema', '7.0.1722330589', 'auto'),
(259, 'schema-ActionScheduler_LoggerSchema', '3.0.1722330589', 'auto'),
(260, 'wp_mail_smtp_initial_version', '4.1.0', 'off'),
(261, 'wp_mail_smtp_version', '4.1.0', 'off'),
(262, 'wp_mail_smtp', 'a:18:{s:4:"mail";a:6:{s:10:"from_email";s:27:"montalbanocoralie@gmail.com";s:9:"from_name";s:13:"nathalie-mota";s:6:"mailer";s:5:"gmail";s:11:"return_path";b:0;s:16:"from_email_force";b:1;s:15:"from_name_force";b:0;}s:4:"smtp";a:7:{s:7:"autotls";b:1;s:4:"auth";b:1;s:4:"host";s:0:"";s:4:"port";s:3:"587";s:10:"encryption";s:3:"tls";s:4:"user";s:0:"";s:4:"pass";s:0:"";}s:7:"general";a:1:{s:29:"summary_report_email_disabled";b:0;}s:5:"gmail";a:10:{s:9:"client_id";s:72:"247357898931-3ghir3hbpa62pttf7nh6v3ob63c183kc.apps.googleusercontent.com";s:13:"client_secret";s:35:"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";s:12:"access_token";a:6:{s:12:"access_token";s:224:"ya29.a0AcM612yg7tM7r-llBV36cVk1hykWTXA-ix9wlhClX0AACdbwF3oEbbMBbys72csRKu7foBYShGzwUrwlawePnzaiX2luPLaXA2iNRhCOUoZiAzELR5OeM2YAIij6V8kL8_ERntGFKcn22vHK94KEVxJ4cIYLWovDhfFVdjK2rgaCgYKAdYSARMSFQHGX2Mi9qsF5IUEXc65pAfozk1UJQ0177";s:10:"expires_in";i:3599;s:5:"scope";s:24:"https://mail.google.com/";s:10:"token_type";s:6:"Bearer";s:7:"created";i:1728726046;s:13:"refresh_token";s:103:"1//03wOWtvlLArg0CgYIARAAGAMSNwF-L9IrgGVRHHvY4YwC6S3EsNvgb7RfZ-tHP8kq_9k5Jo1BsEz0FRAVqkXULzTyDTY0ebHr-BA";}s:13:"refresh_token";s:103:"1//03wOWtvlLArg0CgYIARAAGAMSNwF-L9IrgGVRHHvY4YwC6S3EsNvgb7RfZ-tHP8kq_9k5Jo1BsEz0FRAVqkXULzTyDTY0ebHr-BA";s:12:"user_details";a:1:{s:5:"email";s:27:"montalbanocoralie@gmail.com";}s:23:"one_click_setup_enabled";b:0;s:27:"one_click_setup_credentials";a:2:{s:3:"key";s:0:"";s:5:"token";s:0:"";}s:28:"one_click_setup_user_details";a:1:{s:5:"email";s:0:"";}s:20:"is_setup_wizard_auth";b:0;s:9:"auth_code";s:73:"4/0AVG7fiQupy_-6yExuBgq3DrmvImXoJv_UPiD39fnzz5VYlhUJL0sjIu7SavsJ01OXdzYDQ";}s:9:"sendlayer";a:1:{s:7:"api_key";s:0:"";}s:7:"smtpcom";a:2:{s:7:"api_key";s:0:"";s:7:"channel";s:0:"";}s:10:"sendinblue";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:7:"mailgun";a:3:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";s:6:"region";s:2:"US";}s:8:"sendgrid";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:7:"smtp2go";a:1:{s:7:"api_key";s:0:"";}s:9:"sparkpost";a:2:{s:7:"api_key";s:0:"";s:6:"region";s:2:"US";}s:8:"postmark";a:2:{s:16:"server_api_token";s:0:"";s:14:"message_stream";s:0:"";}s:9:"amazonses";a:3:{s:9:"client_id";s:0:"";s:13:"client_secret";s:0:"";s:6:"region";s:9:"us-east-1";}s:7:"outlook";a:5:{s:9:"client_id";s:0:"";s:13:"client_secret";s:0:"";s:12:"access_token";a:0:{}s:13:"refresh_token";s:0:"";s:12:"user_details";a:1:{s:5:"email";s:0:"";}}s:4:"zoho";a:6:{s:9:"client_id";s:0:"";s:13:"client_secret";s:0:"";s:6:"domain";s:3:"com";s:12:"access_token";a:0:{}s:13:"refresh_token";s:0:"";s:12:"user_details";a:1:{s:5:"email";s:0:"";}}s:4:"logs";a:5:{s:7:"enabled";b:0;s:17:"log_email_content";b:0;s:16:"save_attachments";b:0;s:19:"open_email_tracking";b:0;s:19:"click_link_tracking";b:0;}s:11:"alert_email";a:2:{s:7:"enabled";b:0;s:11:"connections";a:0:{}}s:7:"license";a:4:{s:3:"key";s:0:"";s:10:"is_expired";b:0;s:11:"is_disabled";b:0;s:10:"is_invalid";b:0;}}', 'off'),
(263, 'wp_mail_smtp_activated_time', '1722330589', 'off'),
(264, 'wp_mail_smtp_activated', 'a:1:{s:4:"lite";i:1722330589;}', 'auto'),
(269, 'action_scheduler_lock_async-request-runner', '670a512c8ff998.09814505|1728729448', 'no'),
(273, 'wp_mail_smtp_migration_version', '5', 'on'),
(274, 'wp_mail_smtp_debug_events_db_version', '1', 'on'),
(275, 'wp_mail_smtp_activation_prevent_redirect', '1', 'auto'),
(278, 'wp_mail_smtp_review_notice', 'a:2:{s:4:"time";i:1722330633;s:9:"dismissed";b:0;}', 'auto'),
(288, 'ewww_image_optimizer_aux_folders_completed', 'a:0:{}', 'off'),
(519, 'wp_mail_smtp_notifications', 'a:4:{s:6:"update";i:1728681368;s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'auto'),
(860, 'format_children', 'a:0:{}', 'auto'),
(924, 'autoptimize_imgopt_launched', 'on', 'auto'),
(1717, 'category_children', 'a:0:{}', 'auto'),
(1842, 'wp_mail_smtp_debug', 'a:0:{}', 'off'),
(1843, 'wp_mail_smtp_lite_sent_email_counter', '6', 'on') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1844, 'wp_mail_smtp_lite_weekly_sent_email_counter', 'a:5:{i:32;i:1;i:33;i:1;i:39;i:1;i:40;i:1;i:41;i:2;}', 'on'),
(1928, 'ai1wm_secret_key', 'LPI10GMM1EQ9', 'auto'),
(1931, 'ai1wm_status', 'a:2:{s:4:"type";s:8:"download";s:7:"message";s:341:"<a href="http://nathalie-mota.local/wp-content/ai1wm-backups/nathalie-mota-local-20241012-095313-pu2kne.wpress" class="ai1wm-button-green ai1wm-emphasize ai1wm-button-download" title="nathalie-mota.local" download="nathalie-mota-local-20241012-095313-pu2kne.wpress"><span>Télécharger nathalie-mota.local</span><em>Taille : 747 Ko</em></a>";}', 'auto'),
(1938, 'ai1wm_updater', 'a:0:{}', 'auto'),
(2307, 'ewww_image_optimizer_wizard_complete', '1', 'off'),
(2545, 'wp_mail_smtp_setup_wizard_stats', 'a:3:{s:13:"launched_time";i:1728661587;s:14:"completed_time";i:1728662746;s:14:"was_successful";b:1;}', 'off'),
(2577, 'ewww_image_optimizer_dismiss_review_notice', '1', 'off'),
(2594, 'recovery_mode_email_last_sent', '1728643079', 'auto'),
(2632, 'wpforms_activation_redirect', '1', 'auto'),
(2633, 'wpforms_installation_source', 'wp-mail-smtp-setup-wizard', 'auto'),
(2634, 'wpforms_version', '1.9.1.3', 'auto'),
(2635, 'wpforms_version_lite', '1.9.1.3', 'auto'),
(2636, 'wpforms_activated', 'a:1:{s:4:"lite";i:1728662695;}', 'auto'),
(2641, 'wpforms_versions_lite', 'a:13:{s:5:"1.5.9";i:0;s:7:"1.6.7.2";i:0;s:5:"1.6.8";i:0;s:5:"1.7.5";i:0;s:7:"1.7.5.1";i:0;s:5:"1.7.7";i:0;s:5:"1.8.2";i:0;s:5:"1.8.3";i:0;s:5:"1.8.4";i:0;s:5:"1.8.6";i:0;s:5:"1.8.7";i:0;s:5:"1.9.1";i:0;s:7:"1.9.1.3";i:1728662723;}', 'auto'),
(2642, 'widget_wpforms-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'auto'),
(2643, 'wpforms_settings', 'a:3:{s:13:"modern-markup";s:1:"1";s:20:"modern-markup-is-set";b:1;s:26:"modern-markup-hide-setting";b:1;}', 'auto'),
(2645, '_wpforms_transient_wpforms_htaccess_file', 'a:3:{s:4:"size";i:737;s:5:"mtime";i:1728662725;s:5:"ctime";i:1728662725;}', 'on'),
(2646, 'wpforms_admin_notices', 'a:1:{s:14:"review_request";a:2:{s:4:"time";i:1728662725;s:9:"dismissed";b:0;}}', 'auto'),
(2647, 'wpforms_email_summaries_fetch_info_blocks_last_run', '1728662725', 'auto'),
(2648, 'wpforms_process_forms_locator_status', 'completed', 'auto'),
(2651, 'wpforms_notifications', 'a:4:{s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}s:6:"update";i:1728662759;}', 'auto'),
(2819, '_wpforms_transient_timeout_addons.json', '1729307180', 'off'),
(2820, '_wpforms_transient_addons.json', '1728702380', 'off'),
(2840, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1728729391;}', 'off'),
(2851, 'wpmdb_folder_transfers_core_7a358019-ea73-4ca7-9e5b-6a3c0d3c3eac', 'a:1:{s:11:"wp-includes";a:10:{s:9:"nice_name";s:0:"";s:13:"relative_path";s:12:"\\wp-includes";s:6:"is_dir";b:0;s:13:"absolute_path";s:61:"C:\\Users\\ug\\Local Sites\\nathalie-mota\\app\\public\\\\wp-includes";s:9:"item_size";i:54674;s:4:"size";i:48797863;s:10:"batch_size";i:3102989;s:18:"folder_transferred";i:41428547;s:26:"folder_percent_transferred";d:0.84898281303834966;s:17:"total_transferred";i:3240481;}}', 'off'),
(2885, 'rsssl_show_onboarding', '1', 'off'),
(2888, 'rsssl_encryption_keys_set', '1', 'off'),
(2891, 'rsssl_options', 'a:26:{s:12:"site_has_ssl";s:0:"";s:13:"include_alias";i:1;s:15:"other_host_type";s:12:"infinityfree";s:24:"enabled_captcha_provider";s:4:"none";s:25:"password_change_frequency";s:2:"12";s:23:"login_cookie_expiration";s:2:"48";s:22:"404_blocking_threshold";s:3:"lax";s:29:"404_blocking_lockout_duration";s:0:"";s:27:"limit_login_attempts_amount";s:1:"5";s:29:"limit_login_attempts_duration";s:2:"15";s:40:"limit_login_attempts_locked_out_duration";s:2:"30";s:16:"x_xss_protection";s:4:"zero";s:15:"x_frame_options";s:0:"";s:15:"referrer_policy";s:31:"strict-origin-when-cross-origin";s:12:"hsts_max_age";s:8:"63072000";s:26:"cross_origin_opener_policy";s:8:"disabled";s:28:"cross_origin_resource_policy";s:8:"disabled";s:28:"cross_origin_embedder_policy";s:8:"disabled";s:19:"csp_frame_ancestors";s:4:"self";s:19:"two_fa_grace_period";s:2:"10";s:36:"vulnerability_notification_dashboard";s:1:"l";s:35:"vulnerability_notification_sitewide";s:1:"h";s:38:"vulnerability_notification_email_admin";s:1:"c";s:8:"redirect";s:0:"";s:13:"email_address";s:27:"montalbanocoralie@gmail.com";s:15:"accept_le_terms";i:1;}', 'auto'),
(2894, 'rsssl_current_version', '9.0.2', 'off'),
(2904, 'rsssl_port_check_2082', 'fail', 'off'),
(2908, 'rsssl_6_notice_dismissed', '1', 'off'),
(2909, 'rsssl_port_check_8443', 'fail', 'off'),
(2910, 'rsssl_port_check_2222', 'fail', 'off'),
(2911, 'rsssl_last_tested_http_method', '19', 'off'),
(2912, 'rsssl_http_methods_allowed', 'a:2:{s:11:"not-allowed";a:2:{i:1;s:4:"POST";i:2;s:4:"HEAD";}s:7:"allowed";a:16:{i:0;s:3:"GET";i:1;s:3:"PUT";i:2;s:6:"DELETE";i:3;s:7:"OPTIONS";i:4;s:7:"CONNECT";i:5;s:5:"TRACE";i:6;s:5:"TRACK";i:7;s:5:"PATCH";i:8;s:4:"COPY";i:9;s:4:"LINK";i:10;s:6:"UNLINK";i:11;s:5:"PURGE";i:12;s:4:"LOCK";i:13;s:6:"UNLOCK";i:14;s:8:"PROPFIND";i:15;s:4:"VIEW";}}', 'off'),
(2914, 'rsssl_onboarding_dismissed', '1', 'off'),
(2915, 'rsssl_le_installation_progress', 'a:4:{i:0;s:13:"system-status";i:1;s:6:"domain";i:2;s:10:"generation";i:3;s:12:"installation";}', 'off'),
(2920, 'rsssl_initial_alias_domain_value_set', '1', 'off'),
(2922, 'rsssl_hosting_dashboard', 'cpanel', 'off'),
(2925, 'rsssl_404_cache', 'a:1:{s:3:"::1";a:1:{i:0;i:1728705209;}}', 'off'),
(3014, 'rsssl_plusone_count', '1', 'auto'),
(3015, 'rsssl_admin_notices', 'empty', 'auto'),
(3053, 'action_scheduler_migration_status', 'complete', 'auto') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(3, 5, '_edit_lock', '1722329122:1'),
(10, 9, '_edit_lock', '1722329465:1'),
(12, 13, '_edit_lock', '1722793201:1'),
(13, 15, '_edit_lock', '1722793411:1'),
(24, 19, '_menu_item_type', 'post_type'),
(25, 19, '_menu_item_menu_item_parent', '0'),
(26, 19, '_menu_item_object_id', '9'),
(27, 19, '_menu_item_object', 'page'),
(28, 19, '_menu_item_target', ''),
(29, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(30, 19, '_menu_item_xfn', ''),
(31, 19, '_menu_item_url', ''),
(33, 20, '_menu_item_type', 'post_type'),
(34, 20, '_menu_item_menu_item_parent', '0'),
(35, 20, '_menu_item_object_id', '5'),
(36, 20, '_menu_item_object', 'page'),
(37, 20, '_menu_item_target', ''),
(38, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(39, 20, '_menu_item_xfn', ''),
(40, 20, '_menu_item_url', ''),
(42, 21, '_edit_last', '1'),
(43, 21, '_photo_date', '2019-01-01'),
(44, 21, '_photo_reference', 'bf2385'),
(45, 21, 'Type', 'Argentique'),
(46, 21, '_edit_lock', '1722643020:1'),
(47, 22, '_wp_attached_file', '2024/07/nathalie-0-1-scaled.jpeg'),
(48, 22, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:32:"2024/07/nathalie-0-1-scaled.jpeg";s:8:"filesize";i:354978;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-0-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14029;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-0-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:84676;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-0-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-0-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:55540;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-0-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:154570;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-0-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:242038;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-0-1.jpeg";}'),
(49, 23, '_wp_attached_file', '2024/07/nathalie-1-1-scaled.jpeg'),
(50, 23, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:32:"2024/07/nathalie-1-1-scaled.jpeg";s:8:"filesize";i:584481;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-1-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18017;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-1-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:132006;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-1-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7965;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-1-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:83298;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-1-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:252522;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-1-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:401056;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-1-1.jpeg";}'),
(51, 24, '_wp_attached_file', '2024/07/nathalie-2-1-scaled.jpeg'),
(52, 24, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1544;s:4:"file";s:32:"2024/07/nathalie-2-1-scaled.jpeg";s:8:"filesize";i:907847;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-2-1-300x181.jpeg";s:5:"width";i:300;s:6:"height";i:181;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19255;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-2-1-1024x617.jpeg";s:5:"width";i:1024;s:6:"height";i:617;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:183552;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-2-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9479;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-2-1-768x463.jpeg";s:5:"width";i:768;s:6:"height";i:463;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:109460;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-2-1-1536x926.jpeg";s:5:"width";i:1536;s:6:"height";i:926;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:373840;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-2-1-2048x1235.jpeg";s:5:"width";i:2048;s:6:"height";i:1235;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:618530;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-2-1.jpeg";}'),
(53, 25, '_wp_attached_file', '2024/07/nathalie-3-1-scaled.jpeg'),
(54, 25, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:32:"2024/07/nathalie-3-1-scaled.jpeg";s:8:"filesize";i:237385;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-3-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9577;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-3-1-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:57784;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-3-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4503;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-3-1-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67806;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-3-1-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:104188;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-3-1-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:162701;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-3-1.jpeg";}'),
(55, 26, '_wp_attached_file', '2024/07/nathalie-4-1-scaled.jpeg'),
(56, 26, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1706;s:6:"height";i:2560;s:4:"file";s:32:"2024/07/nathalie-4-1-scaled.jpeg";s:8:"filesize";i:645935;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-4-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17554;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-4-1-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:146035;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-4-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7596;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-4-1-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:176135;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-4-1-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:281102;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-4-1-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:448668;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-4-1.jpeg";}'),
(57, 27, '_wp_attached_file', '2024/07/nathalie-5-1-scaled.jpeg'),
(58, 27, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:32:"2024/07/nathalie-5-1-scaled.jpeg";s:8:"filesize";i:758221;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-5-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18435;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-5-1-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:147713;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-5-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8068;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-5-1-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:179851;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-5-1-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:294798;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-5-1-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:496246;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-5-1.jpeg";}'),
(59, 28, '_wp_attached_file', '2024/07/nathalie-6-1-scaled.jpeg'),
(60, 28, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:2048;s:4:"file";s:32:"2024/07/nathalie-6-1-scaled.jpeg";s:8:"filesize";i:689036;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-6-1-300x240.jpeg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14419;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-6-1-1024x819.jpeg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:112905;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-6-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5847;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-6-1-768x614.jpeg";s:5:"width";i:768;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67678;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-6-1-1536x1229.jpeg";s:5:"width";i:1536;s:6:"height";i:1229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:241982;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-6-1-2048x1638.jpeg";s:5:"width";i:2048;s:6:"height";i:1638;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:433586;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-6-1.jpeg";}'),
(61, 29, '_wp_attached_file', '2024/07/nathalie-7-1-scaled.jpeg'),
(62, 29, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1706;s:4:"file";s:32:"2024/07/nathalie-7-1-scaled.jpeg";s:8:"filesize";i:380424;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-7-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13363;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-7-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:90730;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-7-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6040;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-7-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58147;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-7-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:169001;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-7-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:266019;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-7-1.jpeg";}'),
(63, 30, '_wp_attached_file', '2024/07/nathalie-8-1-scaled.jpeg'),
(64, 30, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1709;s:6:"height";i:2560;s:4:"file";s:32:"2024/07/nathalie-8-1-scaled.jpeg";s:8:"filesize";i:427252;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-8-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16431;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-8-1-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:106129;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-8-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8382;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-8-1-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:126112;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-8-1-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:195415;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-8-1-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:301647;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-8-1.jpeg";}'),
(65, 31, '_wp_attached_file', '2024/07/nathalie-9-1-scaled.jpeg'),
(66, 31, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:32:"2024/07/nathalie-9-1-scaled.jpeg";s:8:"filesize";i:597780;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:25:"nathalie-9-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13921;}s:5:"large";a:5:{s:4:"file";s:26:"nathalie-9-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:111349;}s:9:"thumbnail";a:5:{s:4:"file";s:25:"nathalie-9-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6893;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-9-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67418;}s:9:"1536x1536";a:5:{s:4:"file";s:27:"nathalie-9-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:226691;}s:9:"2048x2048";a:5:{s:4:"file";s:27:"nathalie-9-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:389043;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:17:"nathalie-9-1.jpeg";}'),
(67, 32, '_wp_attached_file', '2024/07/nathalie-10-1-scaled.jpeg'),
(68, 32, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1920;s:4:"file";s:33:"2024/07/nathalie-10-1-scaled.jpeg";s:8:"filesize";i:1285340;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-10-1-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:24481;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-10-1-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:251404;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-10-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9004;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-10-1-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:146050;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-10-1-1536x1152.jpeg";s:5:"width";i:1536;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:529642;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-10-1-2048x1536.jpeg";s:5:"width";i:2048;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:880316;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-10-1.jpeg";}'),
(69, 33, '_wp_attached_file', '2024/07/nathalie-11-1-scaled.jpeg'),
(70, 33, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1709;s:4:"file";s:33:"2024/07/nathalie-11-1-scaled.jpeg";s:8:"filesize";i:347135;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-11-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14579;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-11-1-1024x684.jpeg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87705;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-11-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7169;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-11-1-768x513.jpeg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:57990;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-11-1-1536x1025.jpeg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:157668;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-11-1-2048x1367.jpeg";s:5:"width";i:2048;s:6:"height";i:1367;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:242665;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-11-1.jpeg";}'),
(71, 34, '_wp_attached_file', '2024/07/nathalie-12-1-scaled.jpeg'),
(72, 34, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:2560;s:6:"height";i:1707;s:4:"file";s:33:"2024/07/nathalie-12-1-scaled.jpeg";s:8:"filesize";i:490634;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-12-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17884;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-12-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:122549;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-12-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8897;}s:12:"medium_large";a:5:{s:4:"file";s:26:"nathalie-12-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:78366;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-12-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:224118;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-12-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:347717;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-12-1.jpeg";}'),
(73, 35, '_wp_attached_file', '2024/07/nathalie-13-1-scaled.jpeg'),
(74, 35, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:33:"2024/07/nathalie-13-1-scaled.jpeg";s:8:"filesize";i:268514;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-13-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10048;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-13-1-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65536;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-13-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5359;}s:12:"medium_large";a:5:{s:4:"file";s:27:"nathalie-13-1-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:77831;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-13-1-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:120510;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-13-1-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:186989;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-13-1.jpeg";}'),
(75, 36, '_wp_attached_file', '2024/07/nathalie-14-1-scaled.jpeg'),
(76, 36, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1707;s:6:"height";i:2560;s:4:"file";s:33:"2024/07/nathalie-14-1-scaled.jpeg";s:8:"filesize";i:450275;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-14-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10823;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-14-1-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:91908;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-14-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5178;}s:12:"medium_large";a:5:{s:4:"file";s:27:"nathalie-14-1-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:111805;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-14-1-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:184903;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-14-1-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:304802;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-14-1.jpeg";}'),
(77, 37, '_wp_attached_file', '2024/07/nathalie-15-1-scaled.jpeg'),
(78, 37, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1709;s:6:"height";i:2560;s:4:"file";s:33:"2024/07/nathalie-15-1-scaled.jpeg";s:8:"filesize";i:638948;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"nathalie-15-1-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18229;}s:5:"large";a:5:{s:4:"file";s:27:"nathalie-15-1-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:145631;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"nathalie-15-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8026;}s:12:"medium_large";a:5:{s:4:"file";s:27:"nathalie-15-1-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:175490;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"nathalie-15-1-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:282412;}s:9:"2048x2048";a:5:{s:4:"file";s:28:"nathalie-15-1-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:446586;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:18:"nathalie-15-1.jpeg";}'),
(79, 21, '_thumbnail_id', '22'),
(80, 38, '_menu_item_type', 'post_type'),
(81, 38, '_menu_item_menu_item_parent', '0'),
(82, 38, '_menu_item_object_id', '15'),
(83, 38, '_menu_item_object', 'page'),
(84, 38, '_menu_item_target', ''),
(85, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(86, 38, '_menu_item_xfn', ''),
(87, 38, '_menu_item_url', ''),
(89, 39, '_menu_item_type', 'post_type'),
(90, 39, '_menu_item_menu_item_parent', '0'),
(91, 39, '_menu_item_object_id', '13'),
(92, 39, '_menu_item_object', 'page'),
(93, 39, '_menu_item_target', ''),
(94, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(95, 39, '_menu_item_xfn', ''),
(96, 39, '_menu_item_url', ''),
(101, 42, '_menu_item_type', 'custom'),
(102, 42, '_menu_item_menu_item_parent', '0'),
(103, 42, '_menu_item_object_id', '42'),
(104, 42, '_menu_item_object', 'custom'),
(105, 42, '_menu_item_target', ''),
(106, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 42, '_menu_item_xfn', ''),
(108, 42, '_menu_item_url', ''),
(115, 45, '_edit_last', '1'),
(116, 45, '_edit_lock', '1722643073:1'),
(117, 45, '_thumbnail_id', '23'),
(118, 45, '_photo_date', '2020-01-01'),
(119, 45, '_photo_reference', 'bf2386'),
(120, 45, 'Type', 'Argentique'),
(121, 46, '_edit_last', '1'),
(122, 46, '_edit_lock', '1722643357:1'),
(123, 46, '_thumbnail_id', '24'),
(124, 46, '_photo_date', '2021-01-01'),
(125, 46, '_photo_reference', 'bf2387'),
(126, 46, 'Type', 'Numérique'),
(127, 47, '_edit_last', '1'),
(128, 47, '_edit_lock', '1722643141:1'),
(129, 47, '_photo_date', '2019-01-01'),
(130, 47, '_photo_reference', 'bf2388'),
(131, 47, 'Type', 'Argentique'),
(132, 48, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(133, 48, '_edit_lock', '1722645504:1'),
(134, 48, '_thumbnail_id', '26'),
(135, 48, '_photo_date', '2020-01-01'),
(136, 48, '_photo_reference', 'bf2389'),
(137, 48, 'Type', 'Numérique'),
(138, 49, '_edit_last', '1'),
(139, 49, '_edit_lock', '1722606140:1'),
(140, 49, '_thumbnail_id', '27'),
(141, 49, '_photo_date', '2021-01-01'),
(142, 49, '_photo_reference', 'bf2390'),
(143, 49, 'Type', 'Numérique'),
(144, 50, '_edit_last', '1'),
(145, 50, '_edit_lock', '1722606154:1'),
(146, 50, '_thumbnail_id', '28'),
(147, 50, '_photo_date', '2020-01-01'),
(148, 50, '_photo_reference', 'bf2391'),
(149, 50, 'Type', 'Numérique'),
(150, 51, '_edit_last', '1'),
(151, 51, '_edit_lock', '1722606358:1'),
(152, 51, '_thumbnail_id', '29'),
(153, 51, '_photo_date', '2019-01-01'),
(154, 51, '_photo_reference', 'bf2392'),
(155, 51, 'Type', 'Numérique'),
(156, 52, '_edit_last', '1'),
(157, 52, '_edit_lock', '1722606367:1'),
(158, 52, '_thumbnail_id', '30'),
(159, 52, '_photo_date', '2021-01-01'),
(160, 52, '_photo_reference', 'bf2393'),
(161, 52, 'Type', 'Numérique'),
(162, 53, '_edit_last', '1'),
(163, 53, '_edit_lock', '1722606374:1'),
(164, 53, '_thumbnail_id', '31'),
(165, 53, '_photo_date', '2022-01-01'),
(166, 53, '_photo_reference', 'bf2394'),
(167, 53, 'Type', 'Numérique'),
(168, 54, '_edit_last', '1'),
(169, 54, '_edit_lock', '1722606244:1'),
(170, 54, '_photo_date', '2022-01-01'),
(171, 54, '_photo_reference', 'bf2395'),
(172, 54, 'Type', 'Numérique'),
(173, 54, '_thumbnail_id', '32'),
(174, 55, '_edit_last', '1'),
(175, 55, '_edit_lock', '1722606392:1'),
(176, 55, '_thumbnail_id', '33'),
(177, 55, '_photo_date', '2022-01-01'),
(178, 55, '_photo_reference', 'bf2396'),
(179, 55, 'Type', 'Argentique'),
(180, 56, '_edit_last', '1'),
(181, 56, '_edit_lock', '1722647044:1'),
(182, 56, '_thumbnail_id', '34'),
(183, 56, '_photo_date', '2022-01-01'),
(184, 56, '_photo_reference', 'bf2397'),
(185, 56, 'Type', 'Numérique'),
(186, 57, '_edit_last', '1'),
(187, 57, '_edit_lock', '1722606408:1'),
(188, 57, '_thumbnail_id', '35'),
(189, 57, '_photo_date', '2022-01-01'),
(190, 57, '_photo_reference', 'bf2398'),
(191, 57, 'Type', 'Numérique'),
(192, 58, '_edit_last', '1'),
(193, 58, '_edit_lock', '1722775436:1'),
(194, 58, '_thumbnail_id', '36'),
(195, 58, '_photo_date', '2022-01-01'),
(196, 58, '_photo_reference', 'bf2399'),
(197, 58, 'Type', 'Argentique'),
(198, 59, '_edit_last', '1'),
(199, 59, '_edit_lock', '1722648397:1'),
(200, 59, '_thumbnail_id', '37'),
(201, 59, '_photo_date', '2022-01-01'),
(202, 59, '_photo_reference', 'bf2400'),
(203, 59, 'Type', 'Numérique'),
(204, 47, '_thumbnail_id', '25'),
(205, 39, '_wp_old_date', '2024-07-30'),
(206, 38, '_wp_old_date', '2024-07-30'),
(207, 42, '_wp_old_date', '2024-07-30'),
(211, 61, '_menu_item_type', 'custom'),
(212, 61, '_menu_item_menu_item_parent', '0'),
(213, 61, '_menu_item_object_id', '61'),
(214, 61, '_menu_item_object', 'custom'),
(215, 61, '_menu_item_target', ''),
(216, 61, '_menu_item_classes', 'a:1:{i:0;s:17:"contact-menu-item";}'),
(217, 61, '_menu_item_xfn', ''),
(218, 61, '_menu_item_url', '#contact'),
(220, 20, '_wp_old_date', '2024-07-30'),
(221, 19, '_wp_old_date', '2024-07-30'),
(225, 20, '_wp_old_date', '2024-08-03'),
(226, 19, '_wp_old_date', '2024-08-03'),
(227, 61, '_wp_old_date', '2024-08-03') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-07-26 17:07:05', '2024-07-26 17:07:05', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2024-07-26 17:07:05', '2024-07-26 17:07:05', '', 0, 'http://nathalie-mota.local/?p=1', 0, 'post', '', 1),
(5, 1, '2024-07-30 10:47:43', '2024-07-30 08:47:43', '', 'ACCUEIL', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2024-07-30 10:47:43', '2024-07-30 08:47:43', '', 0, 'http://nathalie-mota.local/?page_id=5', 0, 'page', '', 0),
(6, 1, '2024-07-30 10:47:43', '2024-07-30 08:47:43', '', 'ACCUEIL', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2024-07-30 10:47:43', '2024-07-30 08:47:43', '', 5, 'http://nathalie-mota.local/?p=6', 0, 'revision', '', 0),
(9, 1, '2024-07-30 10:51:22', '2024-07-30 08:51:22', '', 'À PROPOS', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2024-07-30 10:51:22', '2024-07-30 08:51:22', '', 0, 'http://nathalie-mota.local/?page_id=9', 0, 'page', '', 0),
(10, 1, '2024-07-30 10:51:22', '2024-07-30 08:51:22', '', 'À PROPOS', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2024-07-30 10:51:22', '2024-07-30 08:51:22', '', 9, 'http://nathalie-mota.local/?p=10', 0, 'revision', '', 0),
(13, 1, '2024-07-30 10:57:45', '2024-07-30 08:57:45', '', 'MENTIONS LÉGALES', '', 'publish', 'closed', 'closed', '', 'mentions-legales', '', '', '2024-07-30 10:57:45', '2024-07-30 08:57:45', '', 0, 'http://nathalie-mota.local/?page_id=13', 0, 'page', '', 0),
(14, 1, '2024-07-30 10:57:45', '2024-07-30 08:57:45', '', 'MENTIONS LÉGALES', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2024-07-30 10:57:45', '2024-07-30 08:57:45', '', 13, 'http://nathalie-mota.local/?p=14', 0, 'revision', '', 0),
(15, 1, '2024-07-30 10:58:49', '2024-07-30 08:58:49', '', 'VIE PRIVÉE', '', 'publish', 'closed', 'closed', '', 'vie-privee', '', '', '2024-07-30 10:58:49', '2024-07-30 08:58:49', '', 0, 'http://nathalie-mota.local/?page_id=15', 0, 'page', '', 0),
(16, 1, '2024-07-30 10:58:49', '2024-07-30 08:58:49', '', 'VIE PRIVÉE', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-07-30 10:58:49', '2024-07-30 08:58:49', '', 15, 'http://nathalie-mota.local/?p=16', 0, 'revision', '', 0),
(19, 1, '2024-08-04 19:29:07', '2024-07-30 09:00:32', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2024-08-04 19:29:07', '2024-08-04 17:29:07', '', 0, 'http://nathalie-mota.local/?p=19', 2, 'nav_menu_item', '', 0),
(20, 1, '2024-08-04 19:29:07', '2024-07-30 09:00:32', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2024-08-04 19:29:07', '2024-08-04 17:29:07', '', 0, 'http://nathalie-mota.local/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2024-07-30 11:06:34', '2024-07-30 09:06:34', '<img class="alignnone size-medium wp-image-22" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-0-1-300x200.jpeg" alt="" width="300" height="200" />', 'Santé!', '', 'publish', 'closed', 'closed', '', 'sante', '', '', '2024-08-03 01:59:07', '2024-08-02 23:59:07', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=21', 0, 'photo', '', 0),
(22, 1, '2024-07-30 11:07:14', '2024-07-30 09:07:14', '', 'nathalie-0', '', 'inherit', 'open', 'closed', '', 'nathalie-0', '', '', '2024-07-30 11:13:24', '2024-07-30 09:13:24', '', 21, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-0-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2024-07-30 11:07:22', '2024-07-30 09:07:22', '', 'nathalie-1', '', 'inherit', 'open', 'closed', '', 'nathalie-1', '', '', '2024-07-30 11:25:23', '2024-07-30 09:25:23', '', 45, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-1-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2024-07-30 11:07:30', '2024-07-30 09:07:30', '', 'nathalie-2', '', 'inherit', 'open', 'closed', '', 'nathalie-2', '', '', '2024-07-30 11:28:12', '2024-07-30 09:28:12', '', 46, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-2-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2024-07-30 11:07:35', '2024-07-30 09:07:35', '', 'nathalie-3', '', 'inherit', 'open', 'closed', '', 'nathalie-3', '', '', '2024-07-30 11:31:32', '2024-07-30 09:31:32', '', 47, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-3-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2024-07-30 11:07:42', '2024-07-30 09:07:42', '', 'nathalie-4', '', 'inherit', 'open', 'closed', '', 'nathalie-4', '', '', '2024-07-30 11:35:03', '2024-07-30 09:35:03', '', 48, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-4-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2024-07-30 11:07:49', '2024-07-30 09:07:49', '', 'nathalie-5', '', 'inherit', 'open', 'closed', '', 'nathalie-5', '', '', '2024-07-30 11:37:03', '2024-07-30 09:37:03', '', 49, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-5-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2024-07-30 11:07:57', '2024-07-30 09:07:57', '', 'nathalie-6', '', 'inherit', 'open', 'closed', '', 'nathalie-6', '', '', '2024-07-30 11:39:18', '2024-07-30 09:39:18', '', 50, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-6-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2024-07-30 11:08:04', '2024-07-30 09:08:04', '', 'nathalie-7', '', 'inherit', 'open', 'closed', '', 'nathalie-7', '', '', '2024-07-30 11:41:40', '2024-07-30 09:41:40', '', 51, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-7-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2024-07-30 11:08:09', '2024-07-30 09:08:09', '', 'nathalie-8', '', 'inherit', 'open', 'closed', '', 'nathalie-8', '', '', '2024-07-30 11:43:45', '2024-07-30 09:43:45', '', 52, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-8-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2024-07-30 11:08:17', '2024-07-30 09:08:17', '', 'nathalie-9', '', 'inherit', 'open', 'closed', '', 'nathalie-9', '', '', '2024-07-30 11:45:52', '2024-07-30 09:45:52', '', 53, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-9-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2024-07-30 11:08:24', '2024-07-30 09:08:24', '', 'nathalie-10', '', 'inherit', 'open', 'closed', '', 'nathalie-10', '', '', '2024-07-30 11:48:20', '2024-07-30 09:48:20', '', 54, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-10-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2024-07-30 11:08:31', '2024-07-30 09:08:31', '', 'nathalie-11', '', 'inherit', 'open', 'closed', '', 'nathalie-11', '', '', '2024-07-30 11:50:18', '2024-07-30 09:50:18', '', 55, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-11-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2024-07-30 11:08:39', '2024-07-30 09:08:39', '', 'nathalie-12', '', 'inherit', 'open', 'closed', '', 'nathalie-12', '', '', '2024-07-30 11:53:04', '2024-07-30 09:53:04', '', 56, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-12-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2024-07-30 11:08:46', '2024-07-30 09:08:46', '', 'nathalie-13', '', 'inherit', 'open', 'closed', '', 'nathalie-13', '', '', '2024-07-30 11:55:10', '2024-07-30 09:55:10', '', 57, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-13-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2024-07-30 11:08:54', '2024-07-30 09:08:54', '', 'nathalie-14', '', 'inherit', 'open', 'closed', '', 'nathalie-14', '', '', '2024-07-30 11:56:36', '2024-07-30 09:56:36', '', 58, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-14-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2024-07-30 11:09:01', '2024-07-30 09:09:01', '', 'nathalie-15', '', 'inherit', 'open', 'closed', '', 'nathalie-15', '', '', '2024-07-30 11:57:41', '2024-07-30 09:57:41', '', 59, 'http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-15-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2024-08-02 23:35:51', '2024-07-30 09:16:58', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2024-08-02 23:35:51', '2024-08-02 21:35:51', '', 0, 'http://nathalie-mota.local/?p=38', 2, 'nav_menu_item', '', 0),
(39, 1, '2024-08-02 23:35:51', '2024-07-30 09:16:59', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2024-08-02 23:35:51', '2024-08-02 21:35:51', '', 0, 'http://nathalie-mota.local/?p=39', 1, 'nav_menu_item', '', 0),
(42, 1, '2024-08-02 23:35:51', '2024-07-30 09:19:47', '', 'TOUS DROITS RÉSERVÉS', '', 'publish', 'closed', 'closed', '', 'tous-droits-reserves', '', '', '2024-08-02 23:35:51', '2024-08-02 21:35:51', '', 0, 'http://nathalie-mota.local/?p=42', 3, 'nav_menu_item', '', 0),
(45, 1, '2024-07-30 11:25:55', '2024-07-30 09:25:55', '<img class="alignnone size-medium wp-image-23" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-1-1-300x200.jpeg" alt="" width="300" height="200" />', 'Et bon anniversaire!', '', 'publish', 'closed', 'closed', '', 'et-bon-anniversaire', '', '', '2024-07-30 12:04:20', '2024-07-30 10:04:20', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=45', 0, 'photo', '', 0),
(46, 1, '2024-07-30 11:28:28', '2024-07-30 09:28:28', '<img class="alignnone size-medium wp-image-24" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-2-1-300x181.jpeg" alt="" width="300" height="181" />', 'Let\'s party!', '', 'publish', 'closed', 'closed', '', 'lets-party', '', '', '2024-08-03 02:04:34', '2024-08-03 00:04:34', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=46', 0, 'photo', '', 0),
(47, 1, '2024-07-30 11:34:18', '2024-07-30 09:34:18', '<img class="alignnone size-medium wp-image-25" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-3-1-200x300.jpeg" alt="" width="200" height="300" />', 'Tout est installé', '', 'publish', 'closed', 'closed', '', 'tout-est-installe', '', '', '2024-08-03 02:00:53', '2024-08-03 00:00:53', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=47', 0, 'photo', '', 0),
(48, 1, '2024-07-30 11:36:37', '2024-07-30 09:36:37', '<img class="alignnone size-medium wp-image-26" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-4-1-200x300.jpeg" alt="" width="200" height="300" />', 'Vers l\'éternité', '', 'publish', 'closed', 'closed', '', 'vers-leternite', '', '', '2024-08-03 02:06:10', '2024-08-03 00:06:10', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=48', 0, 'photo', '', 0),
(49, 1, '2024-07-30 11:38:53', '2024-07-30 09:38:53', '<img class="alignnone size-medium wp-image-27" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-5-1-200x300.jpeg" alt="" width="200" height="300" />', 'Embrassez la mariée', '', 'publish', 'closed', 'closed', '', 'embrassez-la-mariee', '', '', '2024-07-30 11:38:53', '2024-07-30 09:38:53', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=49', 0, 'photo', '', 0),
(50, 1, '2024-07-30 11:40:38', '2024-07-30 09:40:38', '<img class="alignnone size-medium wp-image-28" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-6-1-300x240.jpeg" alt="" width="300" height="240" />', 'Dansons ensemble', '', 'publish', 'closed', 'closed', '', 'dansons-ensemble', '', '', '2024-07-30 11:41:03', '2024-07-30 09:41:03', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=50', 0, 'photo', '', 0),
(51, 1, '2024-07-30 11:43:16', '2024-07-30 09:43:16', '<img class="alignnone size-medium wp-image-29" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-7-1-300x200.jpeg" alt="" width="300" height="200" />', 'Le menu', '', 'publish', 'closed', 'closed', '', 'le-menu', '', '', '2024-07-30 11:43:16', '2024-07-30 09:43:16', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=51', 0, 'photo', '', 0),
(52, 1, '2024-07-30 11:45:08', '2024-07-30 09:45:08', '<img class="alignnone size-medium wp-image-30" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-8-1-200x300.jpeg" alt="" width="200" height="300" />', 'Au bal masqué', '', 'publish', 'closed', 'closed', '', 'au-bal-masque', '', '', '2024-07-30 11:45:08', '2024-07-30 09:45:08', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=52', 0, 'photo', '', 0),
(53, 1, '2024-07-30 11:47:52', '2024-07-30 09:47:52', '<img class="alignnone size-medium wp-image-31" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-9-1-300x200.jpeg" alt="" width="300" height="200" />', 'Let\'s dance!', '', 'publish', 'closed', 'closed', '', 'lets-dance', '', '', '2024-07-30 12:02:22', '2024-07-30 10:02:22', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=53', 0, 'photo', '', 0),
(54, 1, '2024-07-30 11:49:32', '2024-07-30 09:49:32', '<img class="alignnone size-medium wp-image-32" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-10-1-300x225.jpeg" alt="" width="300" height="225" />', 'Jour de match', '', 'publish', 'closed', 'closed', '', 'jour-de-match', '', '', '2024-07-30 12:01:41', '2024-07-30 10:01:41', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=54', 0, 'photo', '', 0),
(55, 1, '2024-07-30 11:51:33', '2024-07-30 09:51:33', '<img class="alignnone size-medium wp-image-33" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-11-1-300x200.jpeg" alt="" width="300" height="200" />', 'Préparation', '', 'publish', 'closed', 'closed', '', 'preparation', '', '', '2024-07-30 11:51:33', '2024-07-30 09:51:33', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=55', 0, 'photo', '', 0),
(56, 1, '2024-07-30 11:54:45', '2024-07-30 09:54:45', '<img class="alignnone size-medium wp-image-34" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-12-1-300x200.jpeg" alt="" width="300" height="200" />', 'Bière ou eau plate?', '', 'publish', 'closed', 'closed', '', 'biere-ou-eau-plate', '', '', '2024-07-30 11:54:45', '2024-07-30 09:54:45', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=56', 0, 'photo', '', 0),
(57, 1, '2024-07-30 11:56:14', '2024-07-30 09:56:14', '<img class="alignnone size-medium wp-image-35" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-13-1-200x300.jpeg" alt="" width="200" height="300" />', 'Bouquet final', '', 'publish', 'closed', 'closed', '', 'bouquet-final', '', '', '2024-07-30 11:56:14', '2024-07-30 09:56:14', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=57', 0, 'photo', '', 0),
(58, 1, '2024-07-30 11:57:18', '2024-07-30 09:57:18', '<img class="alignnone size-medium wp-image-36" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-14-1-200x300.jpeg" alt="" width="200" height="300" />', 'Du soir au matin', '', 'publish', 'closed', 'closed', '', 'du-soir-au-matin', '', '', '2024-07-30 11:57:18', '2024-07-30 09:57:18', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=58', 0, 'photo', '', 0),
(59, 1, '2024-07-30 11:58:26', '2024-07-30 09:58:26', '<img class="alignnone size-medium wp-image-37" src="http://nathalie-mota.local/wp-content/uploads/2024/07/nathalie-15-1-200x300.jpeg" alt="" width="200" height="300" />', 'Team mariée', '', 'publish', 'closed', 'closed', '', 'team-mariee', '', '', '2024-07-30 12:00:32', '2024-07-30 10:00:32', '', 0, 'http://nathalie-mota.local/?post_type=photo&#038;p=59', 0, 'photo', '', 0),
(61, 1, '2024-08-04 19:29:07', '2024-08-02 22:18:29', '', 'CONTACT', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2024-08-04 19:29:07', '2024-08-04 17:29:07', '', 0, 'http://nathalie-mota.local/?p=61', 3, 'nav_menu_item', '', 0),
(64, 1, '2024-08-05 23:12:13', '2024-08-05 21:12:13', '<!-- wp:navigation-link {"className":" menu-item menu-item-type-post_type menu-item-object-page","description":"","id":"13","kind":"post-type","label":"MENTIONS LÉGALES","opensInNewTab":false,"rel":null,"title":"","type":"page","url":"http://nathalie-mota.local/mentions-legales/"} /--><!-- wp:navigation-link {"className":" menu-item menu-item-type-post_type menu-item-object-page","description":"","id":"15","kind":"post-type","label":"VIE PRIVÉE","opensInNewTab":false,"rel":null,"title":"","type":"page","url":"http://nathalie-mota.local/vie-privee/"} /--><!-- wp:navigation-link {"className":" menu-item menu-item-type-custom menu-item-object-custom","description":"","id":null,"kind":"custom","label":"TOUS DROITS RÉSERVÉS","opensInNewTab":false,"rel":null,"title":"","type":"custom","url":""} /-->', 'FOOTER MENU', '', 'publish', 'closed', 'closed', '', 'footer-menu', '', '', '2024-08-05 23:12:13', '2024-08-05 21:12:13', '', 0, 'http://nathalie-mota.local/footer-menu/', 0, 'wp_navigation', '', 0),
(65, 1, '2024-10-07 20:24:34', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-10-07 20:24:34', '0000-00-00 00:00:00', '', 0, 'http://nathalie-mota.local/?p=65', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(19, 2, 0),
(20, 2, 0),
(21, 3, 0),
(21, 4, 0),
(38, 5, 0),
(39, 5, 0),
(42, 5, 0),
(45, 3, 0),
(45, 4, 0),
(46, 4, 0),
(46, 7, 0),
(47, 9, 0),
(47, 10, 0),
(48, 9, 0),
(48, 10, 0),
(49, 9, 0),
(49, 10, 0),
(50, 4, 0),
(50, 9, 0),
(51, 4, 0),
(51, 9, 0),
(52, 7, 0),
(52, 10, 0),
(53, 4, 0),
(53, 9, 0),
(54, 4, 0),
(54, 11, 0),
(55, 4, 0),
(55, 7, 0),
(56, 4, 0),
(56, 7, 0),
(57, 9, 0),
(57, 10, 0),
(58, 9, 0),
(58, 10, 0),
(59, 9, 0),
(59, 10, 0),
(61, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 3),
(3, 3, 'category', '', 0, 2),
(4, 4, 'format', '', 0, 9),
(5, 5, 'nav_menu', '', 0, 3),
(7, 7, 'category', '', 0, 4),
(9, 9, 'category', '', 0, 9),
(10, 10, 'format', '', 0, 7),
(11, 11, 'category', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'HEADER MENU', 'header-menu', 0),
(3, 'Réception', 'reception', 0),
(4, 'paysage', 'paysage', 0),
(5, 'FOOTER MENU', 'footer-menu', 0),
(7, 'Concert', 'concert', 0),
(9, 'Mariage', 'mariage', 0),
(10, 'portrait', 'portrait', 0),
(11, 'Télévision', 'television', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:"10f36f9c6541219a52801b6178a630ff994f70642533c552017bdbfa5cea1284";a:4:{s:10:"expiration";i:1728766824;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";s:5:"login";i:1728594024;}s:64:"3387c2dc9a28748b65489f4c02cc016257ad5424941696fcda2bcbc45e0a2538";a:4:{s:10:"expiration";i:1728814025;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36";s:5:"login";i:1728641225;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '65'),
(18, 1, 'wp_persisted_preferences', 'a:3:{s:4:"core";a:1:{s:26:"isComplementaryAreaVisible";b:1;}s:14:"core/edit-post";a:1:{s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2024-07-30T08:47:30.373Z";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:15:"title-attribute";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:19:"add-post-type-photo";i:1;s:12:"add-post_tag";i:2;s:10:"add-format";}'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1722330823'),
(23, 1, 'nav_menu_recently_edited', '5') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BLyMeZOgiKd2G3TX9wQzhNyAaf38lH1', 'admin', 'dev-email@wpengine.local', 'http://nathalie-mota.local', '2024-07-26 17:07:05', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpforms_logs`
#

DROP TABLE IF EXISTS `wp_wpforms_logs`;


#
# Table structure of table `wp_wpforms_logs`
#

CREATE TABLE `wp_wpforms_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `types` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `form_id` bigint(20) DEFAULT NULL,
  `entry_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpforms_logs`
#

#
# End of data contents of table `wp_wpforms_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpforms_payment_meta`
#

DROP TABLE IF EXISTS `wp_wpforms_payment_meta`;


#
# Table structure of table `wp_wpforms_payment_meta`
#

CREATE TABLE `wp_wpforms_payment_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpforms_payment_meta`
#

#
# End of data contents of table `wp_wpforms_payment_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpforms_payments`
#

DROP TABLE IF EXISTS `wp_wpforms_payments`;


#
# Table structure of table `wp_wpforms_payments`
#

CREATE TABLE `wp_wpforms_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subtotal_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `discount_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `total_amount` decimal(26,8) NOT NULL DEFAULT '0.00000000',
  `currency` varchar(3) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `entry_id` bigint(20) NOT NULL DEFAULT '0',
  `gateway` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `type` varchar(12) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `mode` varchar(4) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `transaction_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `customer_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subscription_id` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `subscription_status` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `date_created_gmt` datetime NOT NULL,
  `date_updated_gmt` datetime NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`(8)),
  KEY `total_amount` (`total_amount`),
  KEY `type` (`type`(8)),
  KEY `transaction_id` (`transaction_id`(32)),
  KEY `customer_id` (`customer_id`(32)),
  KEY `subscription_id` (`subscription_id`(32)),
  KEY `subscription_status` (`subscription_status`(8)),
  KEY `title` (`title`(64))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpforms_payments`
#

#
# End of data contents of table `wp_wpforms_payments`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpforms_tasks_meta`
#

DROP TABLE IF EXISTS `wp_wpforms_tasks_meta`;


#
# Table structure of table `wp_wpforms_tasks_meta`
#

CREATE TABLE `wp_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpforms_tasks_meta`
#
INSERT INTO `wp_wpforms_tasks_meta` ( `id`, `action`, `data`, `date`) VALUES
(1, 'wpforms_process_forms_locator_scan', 'W10=', '2024-10-11 16:05:24'),
(2, 'wpforms_process_purge_spam', 'W10=', '2024-10-11 16:05:24') ;

#
# End of data contents of table `wp_wpforms_tasks_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpmailsmtp_debug_events`
#

DROP TABLE IF EXISTS `wp_wpmailsmtp_debug_events`;


#
# Table structure of table `wp_wpmailsmtp_debug_events`
#

CREATE TABLE `wp_wpmailsmtp_debug_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_520_ci,
  `initiator` text COLLATE utf8mb4_unicode_520_ci,
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpmailsmtp_debug_events`
#
INSERT INTO `wp_wpmailsmtp_debug_events` ( `id`, `content`, `initiator`, `event_type`, `created_at`) VALUES
(1, 'Mailer: Google / Gmail\r\n{\n  "error": {\n    "code": 401,\n    "message": "Request is missing required authentication credential. Expected OAuth 2 access token, login cookie or other valid authentication credential. See https://developers.google.com/identity/sign-in/web/devconsole-project.",\n    "errors": [\n      {\n        "message": "Login Required.",\n        "domain": "global",\n        "reason": "required",\n        "location": "Authorization",\n        "locationType": "header"\n      }\n    ],\n    "status": "UNAUTHENTICATED",\n    "details": [\n      {\n        "@type": "type.googleapis.com/google.rpc.ErrorInfo",\n        "reason": "CREDENTIALS_MISSING",\n        "domain": "googleapis.com",\n        "metadata": {\n          "service": "gmail.googleapis.com",\n          "method": "caribou.api.proto.MailboxService.SendMessage"\n        }\n      }\n    ]\n  }\n}', '{"file":"C:\\\\Users\\\\ug\\\\Local Sites\\\\nathalie-mota\\\\app\\\\public\\\\wp-includes\\\\class-wp-recovery-mode-email-service.php","line":230}', 0, '2024-10-11 10:37:59') ;

#
# End of data contents of table `wp_wpmailsmtp_debug_events`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpmailsmtp_tasks_meta`
#

DROP TABLE IF EXISTS `wp_wpmailsmtp_tasks_meta`;


#
# Table structure of table `wp_wpmailsmtp_tasks_meta`
#

CREATE TABLE `wp_wpmailsmtp_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wpmailsmtp_tasks_meta`
#
INSERT INTO `wp_wpmailsmtp_tasks_meta` ( `id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2024-07-30 09:10:59') ;

#
# End of data contents of table `wp_wpmailsmtp_tasks_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

